#include "stdafx.h"
#include "ColaD.h"
ColaD::ColaD() {

}

void ColaD::crear(int t) {
	tama�o = t;
	cabeza = -1;
	cola = -1;
}

void ColaD::a�adirCabeza(int n) {
	if (cabeza == -1 && cola == -1) {
		cabeza = 0;
		cola = 0;
		v[0] = n;
	}
	else {
		cola++;
		for (int i=cola; 0 < i; i--) {
			v[i] = v[i-1];
		}
		v[0] = n;
	}
}

void ColaD::a�adirCola(int n) {
	if (cabeza == -1 && cola == -1) {
		cabeza = 0;
		cola = 0;
		v[0] = n;
	}
	else {
		cola++;
		v[cola] = n;
	}
}

void ColaD::eliminarCabeza() {
	cout << "Elemento " << v[0] << " eliminado correctamente." << endl;
	for (int i = 0; i < cola; i++) {
		v[i] = v[i+1];
	}
	v[cola] = 0;
	cola--;
}

void ColaD::eliminarCola() {
	cout << "Elemento " << v[cola] << " eliminado correctamente." << endl;
	v[cola] = 0;
	cola--;
}

void ColaD::mostrarCabeza() {
	for (int i = 0; i <= cola; i++) {
		if (i != cola) {
			cout << v[i] << ", ";
		}
		else {
			cout << v[i] << "." << endl;
		}
	}
}

void ColaD::mostrarCola() {
	int aux[max];
	int c = cola;
	for (int i = 0; i <= cola; i++) {
		aux[i] = v[c];
		c--;
	}
	for (int j = 0; j <= cola; j++) {
		if (j != cola) {
			cout << aux[j] << ", ";
		}
		else {
			cout << aux[j] << "." << endl;
		}
	}
}

bool ColaD::comprobarL() {
	if (cola == (tama�o-1)) {
		return false;
	}
	else {
		return true;
	}
}

bool ColaD::comprobarV() {
	if (cola < 0) {
		return false;
	}
	else {
		return true;
	}
}