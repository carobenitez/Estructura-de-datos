// coladoblee.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <iostream>
#include "ColaD.h"
#include <stdlib.h>
#include "conio.h"
using namespace std;

int main()
{
    int tam, n, opcion;
    ColaD cola;
    cout << "Ingrese el tama�o de la cola: ";
    cin >> tam;
    cola.crear(tam);
    system("cls");
    do {
        cout << "MENU" << endl;
        cout << "1.- Cargar por la cabeza." << endl;
        cout << "2.- Cargar por la cola." << endl;
        cout << "3.- Eliminar por la cabeza." << endl;
        cout << "4.- Eliminar por la cola." << endl;
        cout << "5.- Mostrar de la cabeza a la cola." << endl;
        cout << "6.- Mostrar de la cola a la cabeza." << endl;
        cout << "0.- Salir." << endl;
        cout << "Ingrese la operacion que desea realixar: ";
        cin >> opcion;
        switch (opcion)
        {
        case 1:
            if (cola.comprobarL()) {
                cout << "Ingrese el numero que desea a�adir: ";
                cin >> n;
                cola.a�adirCabeza(n);
            }
            else {
                cout << "Cola llena, elija otra opcion." << endl;
            }
            system("pause");
            system("cls");
            break;
        case 2:
            if (cola.comprobarL()) {
                cout << "Ingrese el numero que desea a�adir: ";
                cin >> n;
                cola.a�adirCola(n);
            }
            else {
                cout << "Cola llena, elija otra opcion." << endl;
            }
            system("pause");
            system("cls");
            break;
        case 3:
            if (cola.comprobarV()) {
                cola.eliminarCabeza();
            }
            else {
                cout << "Cola vacia, elija otra opcion." << endl;
            }
            system("pause");
            system("cls");
            break;
        case 4:
            if (cola.comprobarV()) {
                cola.eliminarCola();
            }
            else {
                cout << "Cola vacia, elija otra opcion." << endl;
            }
            system("pause");
            system("cls");
            break;
        case 5:
            if (cola.comprobarV()) {
                cola.mostrarCabeza();
            }
            else {
                cout << "Cola vacia, ingrese un valor primero." << endl;
            }
            system("pause");
            system("cls");
            break;
        case 6:
            if (cola.comprobarV()) {
                cola.mostrarCola();
            }
            else {
                cout << "Cola vacia, ingrese un valor primero." << endl;
            }
            system("pause");
            system("cls");
            break;
        case 0:
            cout << "Saliendo....";
            break;
        default:
            cout << "Numero ingresado no es una opcion disponible.";
            system("pause");
            system("cls");
            break;
        }
    } while (opcion != 0);
    return 0;
}

