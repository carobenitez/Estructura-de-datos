#pragma once
#include <iostream>
#define max 1000
using namespace std;
class ColaD
{
private:
	int v[max];
	int tama�o;
	int cabeza;
	int cola;
public:
	ColaD();
	void crear(int t);
	void a�adirCabeza(int n);
	void a�adirCola(int n);
	void eliminarCabeza();
	void eliminarCola();
	void mostrarCabeza();
	void mostrarCola();
	bool comprobarL();
	bool comprobarV();
};



