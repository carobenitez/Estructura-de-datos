// colasimple.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "iostream"
#include "conio.h"
#include "Cola.h"
#include <stdlib.h>
using namespace std;

int main()
{int tam, elemento, opc;
Cola cola1;
cout<<"Ingrese el tama�o de la cola: "<<endl;
cin>>tam;
cola1.iniciar(tam);
system("cls");
 do {
        cout << "MENU" << endl;
        cout << "1.- Encolar." << endl;
        cout << "2.- Desencolar." << endl;
        cout << "3.- Mostrar cola." << endl;
        cout << "0.- Salir." << endl;
        cout << "Ingrese la operacion que desea realixar: ";
        cin >> opc;
        switch (opc)
        {
        case 1:
			cout<<"Ingrese el elemento: "<<endl;
			cin>>elemento;
			cola1.encolar(elemento);
			system("pause");
			system("cls");
			break;
		case 2:
			cola1.desencolar();
			system("pause");
			system("cls");
		case 3:
			cola1.Mostrar();
			system("pause");
			system("cls");
			break;
		}
	 } while (opc != 0);
 return 0;
}