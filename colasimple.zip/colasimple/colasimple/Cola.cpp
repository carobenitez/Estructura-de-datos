#include "StdAfx.h"
#include "Cola.h"
#include "iostream"
using namespace std;

Cola::Cola()
{
}


void Cola::iniciar(int t)
{tama�o=t;
final=-1;
}
void Cola::encolar(int elem)
{if(final==-1)
   {final=0;
   cola[0]=elem;
   }
else
   {
	 final++;
   cola[final]=elem;
   }
}
bool Cola::colaVacia()
{if(final==-1)
   return true;
else
   return false;
}
void Cola::desencolar()
{if(!colaVacia())
   {for (int i = 0; i < final; i++) {
		cola[i] = cola[i+1];
	}
	cola[final] = 0;
	final--;
   cout<<"Se ha eliminado el primer elemento de la cola"<<endl;
   }

else
{cout<<"La cola esta vacia!"<<endl;}
}

void Cola::Mostrar()
{cout<<"Mostrando la cola..."<<endl;
for(int i=0; i<final+1; i++)
{cout<<"Cola["<<i<<"] = "<<cola[i]<<endl;
}
}