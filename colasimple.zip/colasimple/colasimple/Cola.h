#pragma once
#define MAX 20
class Cola
{
private:
	int cola[MAX];
	int tama�o;
	int final;
public:
	Cola();
	void iniciar(int t);
	void encolar(int elem);
	void desencolar();
	bool colaVacia();
	void Mostrar();
};

