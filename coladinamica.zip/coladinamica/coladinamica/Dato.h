#pragma once
#include "string"
using namespace std;
class Dato
{
public:
	Dato();
};

