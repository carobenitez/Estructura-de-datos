// coladinamica.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Nodo.h"
#include "iostream"
#include "stdlib.h"
#include "conio.h"
using namespace std;

int main()
{ 
	int opc;
char dato;
Nodo *frente = NULL;
Nodo *fin = NULL;
Nodo nodo1;
do{
	cout<<"\t.:MENU:."<<endl;
	cout<<"1. Insertar un caracter a una cola"<<endl;
	cout<<"2. Mostrando todos los elementos de la cola"<<endl;
	cout<<"3. Salir"<<endl;
	cout<<"Opcion: "<<endl;
	cin>>opc;

	switch(opc){
	 case 1: cout<<"\n Ingrese el caracter para agregar a la cola: ";
		cin>>dato;
		nodo1.encolar(frente,fin,dato);
	    break;
	 case 2: cout<<"\nMostrando los elementos de la cola: ";
	while(frente!=NULL){
			nodo1.mostrarcola(frente,fin,dato);
			if(frente != NULL){
				 cout<<dato<<"";
			 }
			 else{
				 cout<<dato<<".";
			 }
	}
	cout<<endl;
	    break;
     case 3: 
		 break;
	}
	system("pause");
	system("cls");
}while(opc<3 && opc>0);
return 0;
}

