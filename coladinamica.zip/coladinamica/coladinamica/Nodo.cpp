#include "StdAfx.h"
#include "Nodo.h"
#include<locale.h>


Nodo::Nodo()
{
}
void Nodo::encolar(Nodo *&frente,Nodo *&fin,char n)
{Nodo *nuevo_nodo = new Nodo();

nuevo_nodo->dato = n;
nuevo_nodo->siguiente = NULL;

if(colavacia(frente)){
	frente = nuevo_nodo;
}
else{
	fin->siguiente = nuevo_nodo;
}
fin = nuevo_nodo;
}

bool Nodo::colavacia(Nodo *frente)
{if(frente==NULL)
return true;
else
	return false;
}
void Nodo::mostrarcola(Nodo *&frente, Nodo *&fin,char &n)
{n = frente->dato;
Nodo *aux = frente;
if(frente ==NULL){
	fin = NULL;
}
else{
	frente = frente->siguiente;
}
delete aux;
	 
}
