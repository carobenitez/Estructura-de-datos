#pragma once
#include "Dato.h"
#include "iostream"
using namespace std;
class Nodo
{
private:
	char dato;
	Nodo *siguiente;
public:
	Nodo();
	void encolar(Nodo *&frente,Nodo *&fin,char n);
	bool colavacia(Nodo *frente);
	void mostrarcola(Nodo *&frente, Nodo *&fin,char &n);
};

