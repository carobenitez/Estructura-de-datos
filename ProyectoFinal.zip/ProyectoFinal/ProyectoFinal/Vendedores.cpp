#include "StdAfx.h"
#include "Vendedores.h"


Vendedores::Vendedores(void)
{
}
