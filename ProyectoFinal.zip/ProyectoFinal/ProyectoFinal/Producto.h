#pragma once
#include <iostream>
#include <string>
#include <stdlib.h>
#include <msclr\marshal_cppstd.h>
using namespace msclr::interop;
using namespace std;
using namespace System::Windows::Forms;
class Producto
{
public:
	public:
	string nombre_P;
	string categoria;
	int precio;
	int cantidad;
	int codigo;
	Producto* siguiente;
	Producto(void);
};

