#pragma once
#include "ListaDatos.h"
namespace ProyectoFinal {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Comprador
	/// </summary>
	public ref class Comprador : public System::Windows::Forms::Form
	{
	public:
		Comprador(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Comprador()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::DataGridView^  grillaProductos;

	private: System::Windows::Forms::TextBox^  txtCodigo;
	private: System::Windows::Forms::TextBox^  txtCantidad;
	private: System::Windows::Forms::Button^  btbAlquilar;





	private: System::Windows::Forms::Button^  btbMostrar;
	private: System::Windows::Forms::Label^  lblCodigo;

	private: System::Windows::Forms::Label^  lblCantidad;



	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Comprador::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->grillaProductos = (gcnew System::Windows::Forms::DataGridView());
			this->txtCodigo = (gcnew System::Windows::Forms::TextBox());
			this->txtCantidad = (gcnew System::Windows::Forms::TextBox());
			this->btbAlquilar = (gcnew System::Windows::Forms::Button());
			this->btbMostrar = (gcnew System::Windows::Forms::Button());
			this->lblCodigo = (gcnew System::Windows::Forms::Label());
			this->lblCantidad = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaProductos))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Arial Rounded MT Bold", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(137, 27);
			this->label1->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(139, 22);
			this->label1->TabIndex = 0;
			this->label1->Text = L"COMPRADOR";
			// 
			// grillaProductos
			// 
			this->grillaProductos->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grillaProductos->Location = System::Drawing::Point(274, 80);
			this->grillaProductos->Margin = System::Windows::Forms::Padding(2);
			this->grillaProductos->Name = L"grillaProductos";
			this->grillaProductos->RowTemplate->Height = 24;
			this->grillaProductos->Size = System::Drawing::Size(319, 182);
			this->grillaProductos->TabIndex = 1;
			// 
			// txtCodigo
			// 
			this->txtCodigo->Location = System::Drawing::Point(127, 134);
			this->txtCodigo->Margin = System::Windows::Forms::Padding(2);
			this->txtCodigo->Name = L"txtCodigo";
			this->txtCodigo->Size = System::Drawing::Size(110, 20);
			this->txtCodigo->TabIndex = 10;
			// 
			// txtCantidad
			// 
			this->txtCantidad->Location = System::Drawing::Point(127, 173);
			this->txtCantidad->Margin = System::Windows::Forms::Padding(2);
			this->txtCantidad->Name = L"txtCantidad";
			this->txtCantidad->Size = System::Drawing::Size(110, 20);
			this->txtCantidad->TabIndex = 9;
			// 
			// btbAlquilar
			// 
			this->btbAlquilar->Location = System::Drawing::Point(68, 243);
			this->btbAlquilar->Margin = System::Windows::Forms::Padding(2);
			this->btbAlquilar->Name = L"btbAlquilar";
			this->btbAlquilar->Size = System::Drawing::Size(109, 32);
			this->btbAlquilar->TabIndex = 6;
			this->btbAlquilar->Text = L"Alquilar";
			this->btbAlquilar->UseVisualStyleBackColor = true;
			// 
			// btbMostrar
			// 
			this->btbMostrar->Location = System::Drawing::Point(444, 28);
			this->btbMostrar->Name = L"btbMostrar";
			this->btbMostrar->Size = System::Drawing::Size(75, 23);
			this->btbMostrar->TabIndex = 11;
			this->btbMostrar->Text = L"Mostrar";
			this->btbMostrar->UseVisualStyleBackColor = true;
			this->btbMostrar->Click += gcnew System::EventHandler(this, &Comprador::btbMostrar_Click);
			// 
			// lblCodigo
			// 
			this->lblCodigo->AutoSize = true;
			this->lblCodigo->Location = System::Drawing::Point(41, 134);
			this->lblCodigo->Name = L"lblCodigo";
			this->lblCodigo->Size = System::Drawing::Size(40, 13);
			this->lblCodigo->TabIndex = 12;
			this->lblCodigo->Text = L"Codigo";
			// 
			// lblCantidad
			// 
			this->lblCantidad->AutoSize = true;
			this->lblCantidad->Location = System::Drawing::Point(44, 173);
			this->lblCantidad->Name = L"lblCantidad";
			this->lblCantidad->Size = System::Drawing::Size(49, 13);
			this->lblCantidad->TabIndex = 13;
			this->lblCantidad->Text = L"Cantidad";
			this->lblCantidad->Click += gcnew System::EventHandler(this, &Comprador::label3_Click);
			// 
			// Comprador
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(616, 393);
			this->Controls->Add(this->lblCantidad);
			this->Controls->Add(this->lblCodigo);
			this->Controls->Add(this->btbMostrar);
			this->Controls->Add(this->txtCodigo);
			this->Controls->Add(this->txtCantidad);
			this->Controls->Add(this->btbAlquilar);
			this->Controls->Add(this->grillaProductos);
			this->Controls->Add(this->label1);
			this->Margin = System::Windows::Forms::Padding(2);
			this->Name = L"Comprador";
			this->Text = L"Comprador";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaProductos))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label3_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void btbMostrar_Click(System::Object^  sender, System::EventArgs^  e) {
			 ListaDatos lis;
			 lis.listar(grillaProductos);
		 }
};
}
