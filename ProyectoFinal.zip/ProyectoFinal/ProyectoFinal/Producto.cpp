#include "StdAfx.h"
#include "Producto.h"


Producto::Producto(void)
{
	siguiente = NULL;
}
