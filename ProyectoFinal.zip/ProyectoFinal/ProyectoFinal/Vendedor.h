#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include "Lista_Productos.h"
//#include "MetodosDatos.h"
#include "ListaDatos.h"
namespace ProyectoFinal {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;
	/// <summary>
	/// Summary for Vendedor
	/// </summary>
	
	
	public ref class Vendedor : public System::Windows::Forms::Form
	{
	public:
		
		Vendedor(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Vendedor()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btbCargar;
	protected: 

	protected: 
	private: System::Windows::Forms::Label^  lblvendedor;
	private: System::Windows::Forms::TextBox^  txtPrecio;
	private: System::Windows::Forms::TextBox^  txtCategoria;


	private: System::Windows::Forms::TextBox^  txtCantidad;

	private: System::Windows::Forms::TextBox^  txtNombre;


	private: System::Windows::Forms::DataGridView^  grillaProductos;
	private: System::Windows::Forms::Label^  lblCantidad;
	private: System::Windows::Forms::Label^  lblPrecio;
	private: System::Windows::Forms::Label^  lblCategoria;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::Label^  lblNombre;
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Vendedor::typeid));
			this->btbCargar = (gcnew System::Windows::Forms::Button());
			this->lblvendedor = (gcnew System::Windows::Forms::Label());
			this->txtPrecio = (gcnew System::Windows::Forms::TextBox());
			this->txtCategoria = (gcnew System::Windows::Forms::TextBox());
			this->txtCantidad = (gcnew System::Windows::Forms::TextBox());
			this->txtNombre = (gcnew System::Windows::Forms::TextBox());
			this->grillaProductos = (gcnew System::Windows::Forms::DataGridView());
			this->lblCantidad = (gcnew System::Windows::Forms::Label());
			this->lblPrecio = (gcnew System::Windows::Forms::Label());
			this->lblCategoria = (gcnew System::Windows::Forms::Label());
			lblNombre = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaProductos))->BeginInit();
			this->SuspendLayout();
			// 
			// lblNombre
			// 
			lblNombre->AutoSize = true;
			lblNombre->Location = System::Drawing::Point(70, 120);
			lblNombre->Name = L"lblNombre";
			lblNombre->Size = System::Drawing::Size(44, 13);
			lblNombre->TabIndex = 7;
			lblNombre->Text = L"Nombre";
			// 
			// btbCargar
			// 
			this->btbCargar->Location = System::Drawing::Point(139, 306);
			this->btbCargar->Margin = System::Windows::Forms::Padding(2);
			this->btbCargar->Name = L"btbCargar";
			this->btbCargar->Size = System::Drawing::Size(109, 32);
			this->btbCargar->TabIndex = 0;
			this->btbCargar->Text = L"Cargar";
			this->btbCargar->UseVisualStyleBackColor = true;
			this->btbCargar->Click += gcnew System::EventHandler(this, &Vendedor::btbCargar_Click);
			// 
			// lblvendedor
			// 
			this->lblvendedor->AutoSize = true;
			this->lblvendedor->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->lblvendedor->Font = (gcnew System::Drawing::Font(L"Arial Rounded MT Bold", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->lblvendedor->Location = System::Drawing::Point(238, 41);
			this->lblvendedor->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->lblvendedor->Name = L"lblvendedor";
			this->lblvendedor->Size = System::Drawing::Size(117, 26);
			this->lblvendedor->TabIndex = 1;
			this->lblvendedor->Text = L"Vendedor";
			// 
			// txtPrecio
			// 
			this->txtPrecio->Location = System::Drawing::Point(139, 199);
			this->txtPrecio->Margin = System::Windows::Forms::Padding(2);
			this->txtPrecio->Name = L"txtPrecio";
			this->txtPrecio->Size = System::Drawing::Size(110, 20);
			this->txtPrecio->TabIndex = 2;
			// 
			// txtCategoria
			// 
			this->txtCategoria->Location = System::Drawing::Point(139, 240);
			this->txtCategoria->Margin = System::Windows::Forms::Padding(2);
			this->txtCategoria->Name = L"txtCategoria";
			this->txtCategoria->Size = System::Drawing::Size(110, 20);
			this->txtCategoria->TabIndex = 3;
			// 
			// txtCantidad
			// 
			this->txtCantidad->Location = System::Drawing::Point(139, 156);
			this->txtCantidad->Margin = System::Windows::Forms::Padding(2);
			this->txtCantidad->Name = L"txtCantidad";
			this->txtCantidad->Size = System::Drawing::Size(110, 20);
			this->txtCantidad->TabIndex = 4;
			// 
			// txtNombre
			// 
			this->txtNombre->Location = System::Drawing::Point(139, 117);
			this->txtNombre->Margin = System::Windows::Forms::Padding(2);
			this->txtNombre->Name = L"txtNombre";
			this->txtNombre->Size = System::Drawing::Size(110, 20);
			this->txtNombre->TabIndex = 5;
			// 
			// grillaProductos
			// 
			this->grillaProductos->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grillaProductos->Location = System::Drawing::Point(304, 101);
			this->grillaProductos->Margin = System::Windows::Forms::Padding(2);
			this->grillaProductos->Name = L"grillaProductos";
			this->grillaProductos->RowTemplate->Height = 24;
			this->grillaProductos->Size = System::Drawing::Size(261, 172);
			this->grillaProductos->TabIndex = 6;
			// 
			// lblCantidad
			// 
			this->lblCantidad->AutoSize = true;
			this->lblCantidad->Location = System::Drawing::Point(65, 159);
			this->lblCantidad->Name = L"lblCantidad";
			this->lblCantidad->Size = System::Drawing::Size(49, 13);
			this->lblCantidad->TabIndex = 8;
			this->lblCantidad->Text = L"Cantidad";
			// 
			// lblPrecio
			// 
			this->lblPrecio->AutoSize = true;
			this->lblPrecio->Location = System::Drawing::Point(77, 202);
			this->lblPrecio->Name = L"lblPrecio";
			this->lblPrecio->Size = System::Drawing::Size(37, 13);
			this->lblPrecio->TabIndex = 9;
			this->lblPrecio->Text = L"Precio";
			// 
			// lblCategoria
			// 
			this->lblCategoria->AutoSize = true;
			this->lblCategoria->Location = System::Drawing::Point(62, 243);
			this->lblCategoria->Name = L"lblCategoria";
			this->lblCategoria->Size = System::Drawing::Size(52, 13);
			this->lblCategoria->TabIndex = 10;
			this->lblCategoria->Text = L"Categoria";
			// 
			// Vendedor
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(637, 424);
			this->Controls->Add(this->lblCategoria);
			this->Controls->Add(this->lblPrecio);
			this->Controls->Add(this->lblCantidad);
			this->Controls->Add(lblNombre);
			this->Controls->Add(this->grillaProductos);
			this->Controls->Add(this->txtNombre);
			this->Controls->Add(this->txtCantidad);
			this->Controls->Add(this->txtCategoria);
			this->Controls->Add(this->txtPrecio);
			this->Controls->Add(this->lblvendedor);
			this->Controls->Add(this->btbCargar);
			this->Margin = System::Windows::Forms::Padding(2);
			this->Name = L"Vendedor";
			this->Text = L"Vendedor";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaProductos))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}

#pragma endregion
	private: System::Void btbCargar_Click(System::Object^  sender, System::EventArgs^  e) {
				// MetodosDatos *lis = new MetodosDatos("Datos.txt");
				/* 
				 string nombre = marshal_as<std::string>(System::Convert::ToString(txtNombre->Text));
				 int cantidad = System::Convert::ToInt32(txtCantidad->Text);
				 int precio = System::Convert::ToInt32(txtPrecio->Text);
				 string categoria = marshal_as<std::string>(System::Convert::ToString(txtCategoria->Text));
				 //validar si el archivo tiene datos
				 //Validar si el archivo esta abierto
				 lista1.Insertar(lis,nombre,categoria,precio,cantidad);
				 lista1.Mostrar(lis,grillaProductos);*/
				 ListaDatos lis;
				 string nombre = marshal_as<std::string>(System::Convert::ToString(txtNombre->Text));
				 int cantidad = System::Convert::ToInt32(txtCantidad->Text);
				 int precio = System::Convert::ToInt32(txtPrecio->Text);
				 string categoria = marshal_as<std::string>(System::Convert::ToString(txtCategoria->Text));
				 lis.cargar(nombre,categoria,precio,cantidad,1);
				 lis.listar(grillaProductos);
				 /*lis->adicionarNuevo(nombre,categoria,precio,cantidad,1);
				 lis->listar(grillaProductos);*/
			 }
};
}
