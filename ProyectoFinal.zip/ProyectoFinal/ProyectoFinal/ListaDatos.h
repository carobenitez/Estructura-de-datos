#pragma once
#include "StdAfx.h"
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <conio.h>
#include <string>
#include <msclr\marshal_cppstd.h>

using namespace msclr::interop;
using namespace std;
using namespace System::Windows::Forms;

class ListaDatos
{
public:
	string nombre_P;
	string categoria;
	int precio;
	int cantidad;
	int codigo;	
	/*
	ListaDatos(void);
	ListaDatos(string nom, string cat, int pr, int cant, int cod);
	void setDatos(string nom, string cat, int pr, int cant, int cod);
	string getNombre();
	string getCategoria();
	int getPrecio();
	int getCantidad();
	int getCodigo();
	void guardarArchivo(ofstream &fsalida);
	bool leerArchivo(ifstream &fentrada);
	bool eliminar(fstream &fes, int codigo);
	bool modificar(fstream &fes, int codigo);
	bool buscar(ifstream &fentrada, int codigo);
	int getTamBytesRegistro();*/
	ListaDatos(void);
	void cargar(string nom, string cat, int pr, int cant, int cod);
	void listar(DataGridView^ grilla);
	int contar(DataGridView^ grilla);
};

