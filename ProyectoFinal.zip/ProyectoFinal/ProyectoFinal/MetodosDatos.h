#pragma once
/*
#include "StdAfx.h"
#include <iostream>
#include <fstream>
#include <conio.h>
#include <string>
#include "ListaDatos.h"
#include <msclr\marshal_cppstd.h>

using namespace msclr::interop;
using namespace std;
using namespace System::Windows::Forms;
*/
class MetodosDatos
{
	/*
public:
	string nombre_P;
	string categoria;
	int precio;
	int cantidad;
	int codigo;
	string  nomArchivo;
	ListaDatos *List;
	MetodosDatos(string nomArch);
	void introducirDatos(ListaDatos *newReg, string nom, string cat, int pr, int cant, int cod);
	void mostrarRegistro(int cod,DataGridView^ grilla);
	void adicionarNuevo(string nom,string cat, int pr, int cant, int cod);
	void listar(DataGridView^ grilla);
	/*int buscarReg();
	void eliminarReg();
	void modificarReg();*/
};

