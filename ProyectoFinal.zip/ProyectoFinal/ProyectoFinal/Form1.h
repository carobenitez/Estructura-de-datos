#pragma once
#include "Comprador.h"
#include "Informacion.h"
#include "Vendedor.h"
#include "Compradores.h"
namespace ProyectoFinal {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::Button^  btncomprador;
	private: System::Windows::Forms::Button^  btnvendedor;


	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtNombreU;
	private: System::Windows::Forms::TextBox^  txtEdad;



	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  txtNumeroR;

	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::TextBox^  txtNumeroC;

	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  txtEmail;

	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Button^  button3;
	protected: 



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->btncomprador = (gcnew System::Windows::Forms::Button());
			this->btnvendedor = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtNombreU = (gcnew System::Windows::Forms::TextBox());
			this->txtEdad = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtNumeroR = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->txtNumeroC = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->txtEmail = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->button3 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(279, 10);
			this->pictureBox1->Margin = System::Windows::Forms::Padding(2);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(188, 91);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox1->TabIndex = 0;
			this->pictureBox1->TabStop = false;
			this->pictureBox1->Click += gcnew System::EventHandler(this, &Form1::pictureBox1_Click);
			// 
			// btncomprador
			// 
			this->btncomprador->BackColor = System::Drawing::Color::LightBlue;
			this->btncomprador->Font = (gcnew System::Drawing::Font(L"MS Reference Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->btncomprador->Location = System::Drawing::Point(232, 361);
			this->btncomprador->Margin = System::Windows::Forms::Padding(2);
			this->btncomprador->Name = L"btncomprador";
			this->btncomprador->Size = System::Drawing::Size(124, 40);
			this->btncomprador->TabIndex = 1;
			this->btncomprador->Text = L"COMPRADOR";
			this->btncomprador->UseVisualStyleBackColor = false;
			this->btncomprador->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// btnvendedor
			// 
			this->btnvendedor->BackColor = System::Drawing::Color::LightBlue;
			this->btnvendedor->Font = (gcnew System::Drawing::Font(L"MS Reference Sans Serif", 10.2F, System::Drawing::FontStyle::Bold));
			this->btnvendedor->Location = System::Drawing::Point(415, 361);
			this->btnvendedor->Margin = System::Windows::Forms::Padding(2);
			this->btnvendedor->Name = L"btnvendedor";
			this->btnvendedor->Size = System::Drawing::Size(115, 40);
			this->btnvendedor->TabIndex = 2;
			this->btnvendedor->Text = L"VENDEDOR";
			this->btnvendedor->UseVisualStyleBackColor = false;
			this->btnvendedor->Click += gcnew System::EventHandler(this, &Form1::btnvendedor_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label1->Font = (gcnew System::Drawing::Font(L"MS Reference Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(277, 117);
			this->label1->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(198, 20);
			this->label1->TabIndex = 3;
			this->label1->Text = L"INGRESE SUS DATOS";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label2->Font = (gcnew System::Drawing::Font(L"Freestyle Script", 25.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(122, 36);
			this->label2->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(121, 42);
			this->label2->TabIndex = 4;
			this->label2->Text = L"Bienvenido!";
			// 
			// txtNombreU
			// 
			this->txtNombreU->Location = System::Drawing::Point(422, 159);
			this->txtNombreU->Margin = System::Windows::Forms::Padding(2);
			this->txtNombreU->Name = L"txtNombreU";
			this->txtNombreU->Size = System::Drawing::Size(119, 20);
			this->txtNombreU->TabIndex = 5;
			this->txtNombreU->TextChanged += gcnew System::EventHandler(this, &Form1::txtNombreU_TextChanged);
			// 
			// txtEdad
			// 
			this->txtEdad->Location = System::Drawing::Point(422, 194);
			this->txtEdad->Margin = System::Windows::Forms::Padding(2);
			this->txtEdad->Name = L"txtEdad";
			this->txtEdad->Size = System::Drawing::Size(119, 20);
			this->txtEdad->TabIndex = 6;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label3->Font = (gcnew System::Drawing::Font(L"MS Reference Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(218, 159);
			this->label3->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(166, 20);
			this->label3->TabIndex = 7;
			this->label3->Text = L"Nombre de Usuario";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label4->Font = (gcnew System::Drawing::Font(L"MS Reference Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(327, 194);
			this->label4->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(49, 20);
			this->label4->TabIndex = 8;
			this->label4->Text = L"Edad";
			// 
			// txtNumeroR
			// 
			this->txtNumeroR->Location = System::Drawing::Point(422, 230);
			this->txtNumeroR->Margin = System::Windows::Forms::Padding(2);
			this->txtNumeroR->Name = L"txtNumeroR";
			this->txtNumeroR->Size = System::Drawing::Size(119, 20);
			this->txtNumeroR->TabIndex = 9;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label5->Font = (gcnew System::Drawing::Font(L"MS Reference Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(222, 230);
			this->label5->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(158, 19);
			this->label5->TabIndex = 10;
			this->label5->Text = L"Numero de Registro";
			// 
			// txtNumeroC
			// 
			this->txtNumeroC->Location = System::Drawing::Point(422, 264);
			this->txtNumeroC->Margin = System::Windows::Forms::Padding(2);
			this->txtNumeroC->Name = L"txtNumeroC";
			this->txtNumeroC->Size = System::Drawing::Size(119, 20);
			this->txtNumeroC->TabIndex = 12;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label6->Font = (gcnew System::Drawing::Font(L"MS Reference Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(218, 264);
			this->label6->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(166, 19);
			this->label6->TabIndex = 13;
			this->label6->Text = L"Numero de Contacto";
			// 
			// txtEmail
			// 
			this->txtEmail->Location = System::Drawing::Point(422, 297);
			this->txtEmail->Margin = System::Windows::Forms::Padding(2);
			this->txtEmail->Name = L"txtEmail";
			this->txtEmail->Size = System::Drawing::Size(119, 20);
			this->txtEmail->TabIndex = 14;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label7->Font = (gcnew System::Drawing::Font(L"MS Reference Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label7->Location = System::Drawing::Point(319, 294);
			this->label7->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(48, 19);
			this->label7->TabIndex = 15;
			this->label7->Text = L"Email";
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::Color::LightBlue;
			this->button3->Font = (gcnew System::Drawing::Font(L"MS Reference Sans Serif", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button3->Location = System::Drawing::Point(506, 28);
			this->button3->Margin = System::Windows::Forms::Padding(2);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(90, 27);
			this->button3->TabIndex = 16;
			this->button3->Text = L"Informacion";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(624, 452);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->txtEmail);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->txtNumeroC);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->txtNumeroR);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txtEdad);
			this->Controls->Add(this->txtNombreU);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnvendedor);
			this->Controls->Add(this->btncomprador);
			this->Controls->Add(this->pictureBox1);
			this->Margin = System::Windows::Forms::Padding(2);
			this->Name = L"Form1";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterParent;
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label2_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
	
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
		Persona cliente;
		string nombreU = marshal_as<std::string>(System::Convert::ToString(txtNombreU->Text));
		int edad = System::Convert::ToInt32(txtEdad->Text);
		int numeroRegistro = System::Convert::ToInt32(txtNumeroR->Text);
		int numeroContacto = System::Convert::ToInt32(txtNumeroC->Text);
		string email = marshal_as<std::string>(System::Convert::ToString(txtEmail->Text));
		cliente.set_nombre(nombreU);
		cliente.set_edad(edad);
		cliente.set_numero_registro(numeroRegistro);
		cliente.set_numero_contacto(numeroContacto);
		cliente.set_email(email);
		Comprador^ inter1 = gcnew Comprador();
		this->Hide();
		inter1->ShowDialog();
		this->Show();
		 }
private: System::Void btnvendedor_Click(System::Object^  sender, System::EventArgs^  e) {
		Persona cliente;
		string nombreU = marshal_as<std::string>(System::Convert::ToString(txtNombreU->Text));
		int edad = System::Convert::ToInt32(txtEdad->Text);
		int numeroRegistro = System::Convert::ToInt32(txtNumeroR->Text);
		int numeroContacto = System::Convert::ToInt32(txtNumeroC->Text);
		string email = marshal_as<std::string>(System::Convert::ToString(txtEmail->Text));
		cliente.set_nombre(nombreU);
		cliente.set_edad(edad);
		cliente.set_numero_registro(numeroRegistro);
		cliente.set_numero_contacto(numeroContacto);
		cliente.set_email(email);
			 Vendedor^ inter2 = gcnew Vendedor();
			 this->Hide();
			 inter2->ShowDialog();
			 this->Show();
		 }
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
			 Informacion^ inf = gcnew Informacion();
			 inf->ShowDialog();
			 this->Show();
		 }
private: System::Void pictureBox1_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void txtNombreU_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}

