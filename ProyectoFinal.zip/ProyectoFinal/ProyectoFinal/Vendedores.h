#pragma once
#include "Persona.h"
#include "Lista_Productos.h"
class Vendedores
{
public:
	Lista_Productos pertenencias;
	Vendedores(void);
};

